-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2022 at 04:28 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `votingsystem_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `idnum` int(50) NOT NULL,
  `img` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `vote` int(255) NOT NULL,
  `partylistName` varchar(255) NOT NULL,
  `vision` varchar(255) NOT NULL,
  `mission` varchar(255) NOT NULL,
  `agenda` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`idnum`, `img`, `position`, `vote`, `partylistName`, `vision`, `mission`, `agenda`) VALUES
(2, '../uploads/2.jpg', 'vice president', 3, 'independent', 'qwe', 'wqe', 'qwe'),
(3, '../uploads/3.jpg', '1st Year Representative', 10, 'ako budoy', 'qwe', 'qwe', 'qwe'),
(4, '../uploads/4.jpg', 'president', 10, 'party pips', 'qwe', 'qwe', 'qwe'),
(5, '../uploads/5.jpg', 'chairman', 10, 'party pips', 'qwe', 'qwe', 'qwe'),
(6, '../uploads/6.jpg', 'vice chairman', 10, 'ako budoy', 'qwe', 'qwe', 'qqwe'),
(7, '../uploads/7.jpg', 'secretary', 10, 'party pips', 'qwe', 'qwe', 'qwe'),
(8, '../uploads/8.jpg', 'treasurer', 10, 'ako budoy', 'qwe', 'qwe', 'qwe'),
(9, '../uploads/9.jpg', 'auditor', 10, 'party pips', 'qwe', 'qwe', 'qwe'),
(10, '../uploads/10.jpg', 'business manager', 10, 'ako budoy', 'qwe', 'qwe', 'qwe'),
(11, '../uploads/11.jpg', 'pro', 10, 'party pips', 'qwe', 'qwe', 'qwe'),
(12, '../uploads/12.jpg', '2nd Year Representative', 10, 'independent', 'qwe', 'qwe', 'qwe'),
(13, '../uploads/13.jpg', '3rd Year Representative', 10, 'ako budoy', 'qwe', 'qwe', 'qwe'),
(14, '../uploads/14.jpg', '4th Year Representative', 10, 'party pips', 'qwe', 'qwe', 'qwe'),
(15, '../uploads/15.jpg', 'vice president', 1, 'party pips', 'qwe', 'qwe', 'qwe');

-- --------------------------------------------------------

--
-- Table structure for table `partylist`
--

CREATE TABLE `partylist` (
  `partylistName` varchar(255) NOT NULL,
  `createdBy` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `partylist`
--

INSERT INTO `partylist` (`partylistName`, `createdBy`) VALUES
('ako budoy', 2),
('party pips', 4);

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `yearsec` varchar(50) NOT NULL,
  `idnum` int(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `userType` varchar(50) NOT NULL,
  `statusLock` int(50) NOT NULL,
  `voted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`firstname`, `middlename`, `lastname`, `course`, `yearsec`, `idnum`, `password`, `userType`, `statusLock`, `voted`) VALUES
('asd', 'a', 'asd', 'bsit', '3g', 2, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 0),
('vbn', 'vbn', 'vbn', 'bsit', '3g', 3, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 0),
('dfg', 'dfg', 'dfg', 'bsit', '3g', 4, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 0),
('zxc', 'zxc', 'zxc', 'bsit', '3g', 5, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 0),
('456', '456', '456', 'bsit', '3g', 6, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 0),
('678', '678', '678', 'bsit', '3g', 7, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 0),
('890', '890', '890', 'bsit', '3g', 8, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 0),
('ert', 'ert', 'ert', 'bsit', '3g', 9, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 0),
('uio', 'uio', 'uio', 'bsit', '3g', 10, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 0),
('hjk', 'hjk', 'hjk', 'bsit', '3g', 11, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 0),
('bnm', 'bnm', 'bnm', 'bsit', '3g', 12, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 1),
('axz', 'axz', 'axz', 'bsit', '3g', 13, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 0),
('edf', 'edf', 'edf', 'bsit', '3g', 14, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 1),
('tgb', 'tgb', 'tgb', 'bsit', '3g', 15, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user', 3, 1),
('admin', 'admin', 'admin', 'admin', 'admin', 123, '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'admin', 3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD UNIQUE KEY `idnum` (`idnum`);

--
-- Indexes for table `partylist`
--
ALTER TABLE `partylist`
  ADD KEY `partylist` (`createdBy`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`idnum`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `candidates`
--
ALTER TABLE `candidates`
  ADD CONSTRAINT `candidate` FOREIGN KEY (`idnum`) REFERENCES `usertable` (`idnum`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `partylist`
--
ALTER TABLE `partylist`
  ADD CONSTRAINT `partylist` FOREIGN KEY (`createdBy`) REFERENCES `usertable` (`idnum`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
